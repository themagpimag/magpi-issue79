echo "Check Edgetpu API" 
python3 -c "import edgetpu; print('ok')"
sudo apt-get install python-pip
sudo pip3 install python-periphery
sudo apt-get install python3-gst-1.0 python3-gi
